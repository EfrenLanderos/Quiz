class Choice < ApplicationRecord
  belongs_to :question
end
